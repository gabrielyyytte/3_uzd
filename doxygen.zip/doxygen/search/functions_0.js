var searchData=
[
  ['fail_50',['Fail',['../functions_8cpp.html#ae53131b2fd4f192b09e9e38cb81bd403',1,'Fail(const studentas &amp;S):&#160;functions.cpp'],['../functions_8h.html#ae53131b2fd4f192b09e9e38cb81bd403',1,'Fail(const studentas &amp;S):&#160;functions.cpp']]]
];
