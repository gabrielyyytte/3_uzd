var searchData=
[
  ['_7estudentas_85',['~studentas',['../classstudentas.html#a74b639e1a2ffe282686999b931eb4aaa',1,'studentas']]]
];
