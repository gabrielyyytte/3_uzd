var searchData=
[
  ['vardas_41',['vardas',['../classasmuo.html#a946809a4bfc1964b180ffa0c2091fe5d',1,'asmuo']]],
  ['vidurkis_42',['vidurkis',['../classstudentas.html#abf2988b006c0ac6fd3b8654ae68df0cc',1,'studentas']]]
];
