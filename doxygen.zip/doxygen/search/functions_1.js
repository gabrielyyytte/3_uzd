var searchData=
[
  ['galutinis_51',['Galutinis',['../classstudentas.html#a4e6bef3e0a43f149ceda1708e86bb92a',1,'studentas']]],
  ['generacija_52',['generacija',['../functions_8cpp.html#a9773e34d900bdfc2ab815f72e3fda80f',1,'generacija(std::vector&lt; studentas &gt; &amp;A, int i, char vm):&#160;functions.cpp'],['../functions_8h.html#a9773e34d900bdfc2ab815f72e3fda80f',1,'generacija(std::vector&lt; studentas &gt; &amp;A, int i, char vm):&#160;functions.cpp']]],
  ['generacija_5ftxt_53',['generacija_txt',['../functions_8cpp.html#ac52b6c9a36816ca58272c91c07b615a8',1,'generacija_txt(int i, int &amp;nr):&#160;functions.cpp'],['../functions_8h.html#ac52b6c9a36816ca58272c91c07b615a8',1,'generacija_txt(int i, int &amp;nr):&#160;functions.cpp']]],
  ['get_5fegz_54',['get_egz',['../classstudentas.html#a8e000a14dc7e0c48806cc0bf7830bef9',1,'studentas']]],
  ['get_5fpavarde_55',['get_pavarde',['../classasmuo.html#af0277261b29a67eb169b3127f4949d14',1,'asmuo']]],
  ['get_5fvardas_56',['get_vardas',['../classasmuo.html#aec99f3f2a2e21bedb45e3c900ab477b5',1,'asmuo']]]
];
