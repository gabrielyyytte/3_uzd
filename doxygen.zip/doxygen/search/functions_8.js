var searchData=
[
  ['set_5fegz_75',['set_egz',['../classstudentas.html#afcb9b16342e39049945db32a3fda3dbc',1,'studentas']]],
  ['set_5fpavarde_76',['set_pavarde',['../classasmuo.html#af85a60e95b8e3b3c0a6b2a59e3e038c0',1,'asmuo']]],
  ['set_5fvardas_77',['set_vardas',['../classasmuo.html#ad7e150306b03ec9a11fc0bba553d2d8b',1,'asmuo']]],
  ['skaicius_78',['skaicius',['../functions_8cpp.html#a0cacfccb42e865ffa2a3a1acc0e7afb9',1,'functions.cpp']]],
  ['skaitymas_79',['skaitymas',['../functions_8cpp.html#ae32fc266a0844a40e7dc21cf5e7a6e72',1,'skaitymas(std::vector&lt; studentas &gt; &amp;A, int &amp;nr, char vm):&#160;functions.cpp'],['../functions_8h.html#ae32fc266a0844a40e7dc21cf5e7a6e72',1,'skaitymas(std::vector&lt; studentas &gt; &amp;A, int &amp;nr, char vm):&#160;functions.cpp']]],
  ['skaitymas_5fv_80',['skaitymas_v',['../functions_8cpp.html#aec08a7a1a8dcb75abb7b747cc2572e65',1,'skaitymas_v(std::vector&lt; studentas &gt; &amp;A, int &amp;i, char vm):&#160;functions.cpp'],['../functions_8h.html#aec08a7a1a8dcb75abb7b747cc2572e65',1,'skaitymas_v(std::vector&lt; studentas &gt; &amp;A, int &amp;i, char vm):&#160;functions.cpp']]],
  ['spausdinimas_81',['spausdinimas',['../functions_8cpp.html#a3d5c0ac50ff3a61bee13c1209a7f77f1',1,'spausdinimas(std::vector&lt; studentas &gt; &amp;A, int i, int did_vard, int did_pav):&#160;functions.cpp'],['../functions_8h.html#a3d5c0ac50ff3a61bee13c1209a7f77f1',1,'spausdinimas(std::vector&lt; studentas &gt; &amp;A, int i, int did_vard, int did_pav):&#160;functions.cpp']]],
  ['spausdinimasrez_5fv_82',['spausdinimasrez_v',['../functions_8cpp.html#a1991aaafb9268f2bb560ceed4a5c5646',1,'spausdinimasrez_v(std::vector&lt; studentas &gt; &amp;kieti, std::vector&lt; studentas &gt; &amp;silpni, int &amp;x):&#160;functions.cpp'],['../functions_8h.html#a1991aaafb9268f2bb560ceed4a5c5646',1,'spausdinimasrez_v(std::vector&lt; studentas &gt; &amp;kieti, std::vector&lt; studentas &gt; &amp;silpni, int &amp;x):&#160;functions.cpp']]],
  ['studentas_83',['studentas',['../classstudentas.html#a40a99ea5d527a3d443123f4785550787',1,'studentas::studentas()'],['../classstudentas.html#abb454b4f5590961e82cb6deb16cebd62',1,'studentas::studentas(std::string v, std::string p, double e)']]]
];
