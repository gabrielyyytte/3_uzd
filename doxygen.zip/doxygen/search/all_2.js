var searchData=
[
  ['fail_2',['Fail',['../functions_8cpp.html#ae53131b2fd4f192b09e9e38cb81bd403',1,'Fail(const studentas &amp;S):&#160;functions.cpp'],['../functions_8h.html#ae53131b2fd4f192b09e9e38cb81bd403',1,'Fail(const studentas &amp;S):&#160;functions.cpp']]],
  ['functions_2ecpp_3',['functions.cpp',['../functions_8cpp.html',1,'']]],
  ['functions_2eh_4',['functions.h',['../functions_8h.html',1,'']]]
];
