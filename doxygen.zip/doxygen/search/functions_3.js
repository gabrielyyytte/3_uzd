var searchData=
[
  ['kiekis_58',['kiekis',['../functions_8cpp.html#a49ee402469ecd16ee49dea53f765bd7c',1,'kiekis(int &amp;k):&#160;functions.cpp'],['../functions_8h.html#a49ee402469ecd16ee49dea53f765bd7c',1,'kiekis(int &amp;k):&#160;functions.cpp']]]
];
