var searchData=
[
  ['vidurkis_84',['vidurkis',['../classstudentas.html#abf2988b006c0ac6fd3b8654ae68df0cc',1,'studentas']]]
];
