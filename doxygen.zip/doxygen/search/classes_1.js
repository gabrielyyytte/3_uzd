var searchData=
[
  ['studentas_45',['studentas',['../classstudentas.html',1,'']]]
];
